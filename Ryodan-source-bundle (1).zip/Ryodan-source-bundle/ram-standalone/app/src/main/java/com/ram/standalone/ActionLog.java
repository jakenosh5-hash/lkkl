package com.ram.standalone;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;

final class ActionLog {
    private static final String PREFS = "ryodan_bridge";
    private static final String LOG = "events";
    private final SharedPreferences prefs;
    ActionLog(Context context) { prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    synchronized void append(String message) {
        try {
            JSONArray a = new JSONArray(prefs.getString(LOG, "[]"));
            a.put(message);
            while (a.length() > 100) a.remove(0);
            prefs.edit().putString(LOG, a.toString()).apply();
        } catch (Exception ignored) { }
    }
    synchronized String read() { return prefs.getString(LOG, "[]"); }
}
