from __future__ import annotations
import hashlib, json, mimetypes, time
from pathlib import Path
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool
from ram_orchestrator import RamOrchestrator

app = FastAPI(title='Ram local interface')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])
ram = RamOrchestrator()
ATTACHMENTS = Path(__file__).parent / 'local_attachments'
WALLPAPERS = Path(__file__).parent / 'wallpapers'
ATTACHMENTS.mkdir(exist_ok=True)
app.mount('/attachments', StaticFiles(directory=ATTACHMENTS), name='attachments')
app.mount('/wallpapers', StaticFiles(directory=WALLPAPERS), name='wallpapers')

@app.get('/health')
def health():
    return {'ok': True, 'service': 'ram-bridge', 'session_file': 'local'}

class ChatReq(BaseModel):
    text: str = ''
    conversation_id: str | None = None
    reply_to: str | None = None
    attachment_ids: list[str] = []
    thinking: bool = False
    search: bool = False

@app.get('/', response_class=HTMLResponse)
def index():
    return HTMLResponse((Path(__file__).parent / 'ram_ui.html').read_text(encoding='utf-8'))

@app.post('/api/upload')
async def upload(file: UploadFile = File(...)):
    raw = await file.read()
    if len(raw) > 25 * 1024 * 1024:
        return {'ok': False, 'error': 'الملف أكبر من 25MB'}
    safe_name = Path(file.filename or 'attachment').name
    digest = hashlib.sha256(raw).hexdigest()[:16]
    stored = ATTACHMENTS / f'{digest}_{safe_name}'
    stored.write_bytes(raw)
    return {'ok': True, 'id': stored.name, 'name': safe_name, 'size': len(raw),
            'content_type': file.content_type or mimetypes.guess_type(safe_name)[0] or 'application/octet-stream'}

@app.post('/api/chat')
async def chat(req: ChatReq):
    parts = []
    if req.reply_to:
        parts.append(f'[REPLY_TO_MESSAGE]\n{req.reply_to}\n[/REPLY_TO_MESSAGE]')
    if req.attachment_ids:
        names = []
        for aid in req.attachment_ids:
            p = ATTACHMENTS / Path(aid).name
            if p.exists(): names.append(p.name)
        if names:
            parts.append('[ATTACHMENTS]\n' + '\n'.join(names) + '\n[/ATTACHMENTS]')
    parts.append(req.text or 'حلّل المرفق المضاف واذكر ما تستطيع قراءته.')
    prompt = '\n\n'.join(parts)
    result = await run_in_threadpool(ram.chat, prompt, req.conversation_id, req.thinking, req.search)
    return {'conversation_id': result.conversation_id, 'messages': result.data['messages'],
            'quotes': result.data['quotes'], 'actions': result.data['actions'],
            'memory_writes': result.data['memory_writes'], 'confidence': result.data['confidence']}
