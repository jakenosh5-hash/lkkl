package com.ram.standalone;

import android.content.Context;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;

/** Local, user-visible action bridge with a fixed action allow-list. */
public final class RyodanBridge {
    private final Context context;
    private final ActionLog log;

    public RyodanBridge(Context context) {
        this.context = context.getApplicationContext();
        this.log = new ActionLog(this.context);
    }

    @JavascriptInterface
    public String execute(String actionJson) {
        try {
            JSONObject action = new JSONObject(actionJson);
            String type = action.optString("type", "");
            JSONObject result = new JSONObject();
            result.put("processed", true);
            result.put("type", type);
            switch (type) {
                case "ping":
                    result.put("status", "ready");
                    break;
                case "log_event":
                    log.append(action.optString("message", "event"));
                    result.put("status", "recorded");
                    break;
                case "set_theme":
                case "set_wallpaper":
                case "new_chat":
                    // UI-owned actions are accepted only as structured events.
                    log.append(type);
                    result.put("status", "queued_for_ui");
                    break;
                default:
                    result.put("processed", false);
                    result.put("status", "not_allowed");
            }
            return result.toString();
        } catch (Exception e) {
            return "{\"processed\":false,\"status\":\"invalid_action\"}";
        }
    }

    @JavascriptInterface
    public String recentLog() { return log.read(); }
}
