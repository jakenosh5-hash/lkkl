# Ryodan — Source Bundle

تتضمن الحزمة:

- مشروع Android الكامل داخل `ram-standalone/`.
- واجهة Ram وملفات الخلفيات والشعار.
- طبقة الواجهة المحلية في `deepseek-bridge/ram_web.py` و`ram_orchestrator.py`.
- مواصفة الشخصية داخل `spec/Ram4.txt`.

للبناء:

```bash
export ANDROID_SDK_ROOT=/path/to/android-sdk
gradle --no-daemon assembleDebug
```

يُبنى التطبيق من مجلد `ram-standalone`.
